import ILovePDFFile from '@ilovepdf/ilovepdf-js-core/utils/ILovePDFFile';
export default ILovePDFFile;
module.exports = ILovePDFFile;