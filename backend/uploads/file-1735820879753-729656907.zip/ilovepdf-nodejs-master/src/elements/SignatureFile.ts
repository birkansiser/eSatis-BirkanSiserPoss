import SignatureFile from '@ilovepdf/ilovepdf-js-core/tasks/sign/elements/SignatureFile';
export default SignatureFile;
module.exports = SignatureFile;
