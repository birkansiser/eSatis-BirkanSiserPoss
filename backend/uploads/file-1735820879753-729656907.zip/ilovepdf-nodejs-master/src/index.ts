import ILovePDFApi from "./ILovePDFApi";
// Expose only the API. As ES module and CommonJS.
export default ILovePDFApi;
module.exports = ILovePDFApi;