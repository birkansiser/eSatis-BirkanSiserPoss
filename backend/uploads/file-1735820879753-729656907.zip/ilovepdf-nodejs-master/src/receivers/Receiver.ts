import Receiver from '@ilovepdf/ilovepdf-js-core/tasks/sign/receivers/Receiver';
export default Receiver;
module.exports = Receiver;
