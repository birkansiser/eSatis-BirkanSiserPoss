import Signer from '@ilovepdf/ilovepdf-js-core/tasks/sign/receivers/Signer';
export default Signer;
module.exports = Signer;
