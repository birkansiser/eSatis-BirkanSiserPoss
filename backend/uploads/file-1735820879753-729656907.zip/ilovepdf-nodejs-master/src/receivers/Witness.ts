import Witness from '@ilovepdf/ilovepdf-js-core/tasks/sign/receivers/Witness';
export default Witness;
module.exports = Witness;
