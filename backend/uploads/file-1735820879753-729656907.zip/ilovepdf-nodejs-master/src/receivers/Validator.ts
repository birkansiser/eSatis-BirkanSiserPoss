import Validator from '@ilovepdf/ilovepdf-js-core/tasks/sign/receivers/Validator';
export default Validator;
module.exports = Validator;
